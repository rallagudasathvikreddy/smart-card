# Hyderabad Smart Card Portal - Setup Guide

## Overview

The Hyderabad Smart Card Portal is a comprehensive digital platform for managing public transport smart cards. It enables citizens to register cards, check balances, recharge online, and apply for travel passes.

## Features Implemented

### User Features
- **User Authentication**: Email/password login and registration
- **Dashboard**: Overview of cards, balances, and passes
- **Card Registration**: Apply for new smart cards (General, Student, Senior Citizen)
- **Balance Check**: View real-time card balance and transaction history
- **Online Recharge**: Recharge cards using Stripe payment gateway
- **Pass Application**: Apply for daily, weekly, or monthly travel passes
- **My Passes**: View and manage all travel passes

### Admin Features
- **Admin Dashboard**: Complete system overview
- **User Management**: View all registered users
- **Card Management**: Monitor all issued cards
- **Pass Management**: Approve and manage pass applications
- **Transaction Reports**: View all system transactions

## Technology Stack

- **Frontend**: React + TypeScript + Vite
- **UI Framework**: shadcn/ui + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **Payment**: Stripe
- **Deployment**: Ready for production deployment

## Prerequisites

Before you begin, ensure you have:
- Node.js 18+ installed
- A Supabase account (already configured)
- A Stripe account for payment processing

## Environment Setup

The following environment variables are already configured in `.env`:

```
VITE_APP_ID=app-7v0md1fr9fy9
VITE_SUPABASE_URL=https://jopwrkhnsplhcrrrjwph.supabase.co
VITE_SUPABASE_ANON_KEY=[already configured]
```

## Stripe Configuration (REQUIRED)

To enable payment functionality, you need to configure your Stripe secret key:

### Step 1: Get Your Stripe Secret Key

1. Go to [Stripe Dashboard](https://dashboard.stripe.com/apikeys)
2. Sign in or create an account
3. Navigate to **Developers** → **API keys**
4. Copy your **Secret key** (starts with `sk_test_` for test mode or `sk_live_` for production)

### Step 2: Add Stripe Secret to Supabase

You need to add the Stripe secret key to your Supabase project:

1. Go to your [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project: `hyderabad-smart-card`
3. Navigate to **Project Settings** → **Edge Functions** → **Secrets**
4. Click **Add new secret**
5. Add the following secret:
   - Name: `STRIPE_SECRET_KEY`
   - Value: Your Stripe secret key (e.g., `sk_test_...`)
6. Click **Save**

**Important**: Without this configuration, payment features (recharge and pass purchase) will not work.

## Database Schema

The system uses the following database tables:

- **profiles**: User information and roles
- **cards**: Smart card details and balances
- **transactions**: All card transactions (recharge, deduction, refund)
- **passes**: Travel pass applications and active passes
- **orders**: Payment orders for Stripe integration

## User Roles

### First User (Administrator)
- The first user to register will automatically become an **admin**
- Admins have access to the Admin Dashboard at `/admin`
- Admins can view all users, cards, passes, and transactions

### Regular Users
- All subsequent users will have the **user** role
- Users can manage their own cards and passes
- Users can only view their own data

## Getting Started

### 1. Register Your Account

1. Navigate to the application
2. Click **Sign Up** on the login page
3. Fill in your details:
   - Full Name
   - Email
   - Phone Number (optional)
   - Password (minimum 6 characters)
4. Click **Create Account**
5. You will be automatically logged in

**Note**: The first registered user becomes the administrator.

### 2. Register a Smart Card

1. Go to **Dashboard** → **Register New Card**
2. Fill in your personal information:
   - Full Name
   - Phone Number
   - ID Proof Type (Aadhar, PAN, etc.)
   - ID Proof Number
   - Card Type (General, Student, or Senior Citizen)
3. Click **Register Card**
4. Your card will be issued immediately with a unique 16-digit card number

### 3. Recharge Your Card

1. Go to **Balance & Recharge**
2. Select your card (if you have multiple)
3. Click **Recharge**
4. Choose a predefined amount or enter a custom amount
5. Click **Proceed to Payment**
6. Complete payment on Stripe's secure checkout page
7. You will be redirected back after successful payment

### 4. Apply for a Travel Pass

1. Go to **Apply for Pass**
2. Select your card
3. Choose pass type:
   - Daily Pass (₹50)
   - Weekly Pass (₹300)
   - Monthly Pass (₹1000)
   - Student Pass (₹600)
   - Senior Citizen Pass (₹500)
4. Select route/zone
5. Click **Proceed to Payment**
6. Complete payment to activate your pass

## Admin Features

If you are an administrator, you can access additional features:

1. Click on your profile in the header
2. Select **Admin Dashboard**
3. View system statistics and manage:
   - All users and their roles
   - All registered cards
   - All pass applications
   - All transactions

## Payment Testing

For testing payments without real money:

1. Use Stripe test mode (keys starting with `sk_test_`)
2. Use test card numbers:
   - Success: `4242 4242 4242 4242`
   - Decline: `4000 0000 0000 0002`
   - Any future expiry date (e.g., 12/34)
   - Any 3-digit CVC

## Security Features

- **Row Level Security (RLS)**: Users can only access their own data
- **Secure Payments**: All payments processed through Stripe
- **Edge Functions**: Sensitive operations run server-side
- **Authentication**: Email/password authentication with Supabase Auth

## Support

For issues or questions:
- Check the FAQ section (coming soon)
- Contact system administrator
- Review transaction history for payment issues

## Important Notes

1. **Card Validity**: Cards are valid for 5 years from issue date
2. **Initial Balance**: New cards start with ₹0 balance
3. **Pass Activation**: Passes activate immediately after payment
4. **Refunds**: Contact administrator for refund requests
5. **Data Security**: All personal information is encrypted and secure

## Development

To run the application locally:

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Run linting
npm run lint
```

## Deployment

The application is ready for deployment. Ensure:
1. Stripe secret key is configured in Supabase
2. Environment variables are set correctly
3. Database migrations are applied
4. Edge Functions are deployed

## License

This project is part of the Digital Telangana initiative for smart city development.
