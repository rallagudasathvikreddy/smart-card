import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/components/auth/AuthProvider';
import { passesApi } from '@/db/api';
import type { Pass } from '@/types/types';
import { Ticket, Plus } from 'lucide-react';

export default function MyPasses() {
  const { user } = useAuth();
  const [passes, setPasses] = useState<Pass[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadPasses();
    }
  }, [user]);

  const loadPasses = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const passesData = await passesApi.getUserPasses(user.id);
      setPasses(passesData);
    } catch (error) {
      console.error('Error loading passes:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-secondary text-secondary-foreground';
      case 'pending':
        return 'bg-accent text-accent-foreground';
      case 'expired':
        return 'bg-muted text-muted-foreground';
      case 'cancelled':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">My Passes</h1>
          <p className="text-muted-foreground mt-2">
            View and manage your travel passes
          </p>
        </div>
        <Link to="/apply-pass">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Apply for Pass
          </Button>
        </Link>
      </div>

      {passes.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Ticket className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Passes Yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Apply for a travel pass to get unlimited rides
            </p>
            <Link to="/apply-pass">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Apply for Pass
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {passes.map((pass) => (
            <Card key={pass.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="capitalize">
                      {pass.pass_type.replace('_', ' ')} Pass
                    </CardTitle>
                    <CardDescription>{pass.route_zone}</CardDescription>
                  </div>
                  <Badge className={getStatusColor(pass.status)}>
                    {pass.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Price</p>
                    <p className="font-semibold">₹{Number(pass.price).toFixed(2)}</p>
                  </div>
                  {pass.start_date && (
                    <div>
                      <p className="text-sm text-muted-foreground">Start Date</p>
                      <p className="font-semibold">
                        {new Date(pass.start_date).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                  {pass.end_date && (
                    <div>
                      <p className="text-sm text-muted-foreground">End Date</p>
                      <p className="font-semibold">
                        {new Date(pass.end_date).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-muted-foreground">Applied On</p>
                    <p className="font-semibold">
                      {new Date(pass.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
