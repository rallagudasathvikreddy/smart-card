import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/components/auth/AuthProvider';
import { cardsApi, passesApi } from '@/db/api';
import { supabase } from '@/db/supabase';
import { useToast } from '@/hooks/use-toast';
import type { Card as CardType, PassType } from '@/types/types';
import { Ticket, CheckCircle2 } from 'lucide-react';

const PASS_PRICING = {
  daily: { price: 50, duration: '1 Day', description: 'Unlimited travel for one day' },
  weekly: { price: 300, duration: '7 Days', description: 'Unlimited travel for one week' },
  monthly: { price: 1000, duration: '30 Days', description: 'Unlimited travel for one month' },
  student: { price: 600, duration: '30 Days', description: 'Monthly pass for students (50% off)' },
  senior_citizen: { price: 500, duration: '30 Days', description: 'Monthly pass for senior citizens (50% off)' },
};

const ROUTE_ZONES = [
  { id: 'zone-a', name: 'Zone A', description: 'Central Hyderabad' },
  { id: 'zone-b', name: 'Zone B', description: 'Extended City Areas' },
  { id: 'zone-c', name: 'Zone C', description: 'Outer City & Suburbs' },
  { id: 'all-zones', name: 'All Zones', description: 'Complete city coverage' },
];

export default function ApplyPass() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [cards, setCards] = useState<CardType[]>([]);
  const [selectedCard, setSelectedCard] = useState('');
  const [passType, setPassType] = useState<PassType>('monthly');
  const [routeZone, setRouteZone] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (user) {
      loadCards();
    }
  }, [user]);

  const loadCards = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const cardsData = await cardsApi.getUserCards(user.id);
      setCards(cardsData.filter((card) => card.status === 'active'));
      if (cardsData.length > 0) {
        setSelectedCard(cardsData[0].id);
      }
    } catch (error) {
      console.error('Error loading cards:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedCard || !routeZone) return;

    setSubmitting(true);
    try {
      const pricing = PASS_PRICING[passType];
      
      await passesApi.createPass({
        user_id: user.id,
        card_id: selectedCard,
        pass_type: passType,
        route_zone: routeZone,
        price: pricing.price,
        status: 'pending',
        start_date: null,
        end_date: null,
        document_url: null,
      });

      const { data, error } = await supabase.functions.invoke('create_stripe_checkout', {
        body: {
          items: [
            {
              name: `${passType.replace('_', ' ')} Pass - ${routeZone}`,
              price: pricing.price,
              quantity: 1,
            },
          ],
          currency: 'inr',
        },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to create checkout session');
      }

      if (data?.url) {
        window.open(data.url, '_blank');
        setSuccess(true);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to apply for pass',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  if (success) {
    return (
      <div className="container mx-auto p-6 max-w-2xl">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="p-4 bg-secondary/10 rounded-full mb-6">
              <CheckCircle2 className="h-16 w-16 text-secondary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Pass Application Submitted!</h2>
            <p className="text-muted-foreground text-center mb-6">
              Complete the payment to activate your pass
            </p>
            <div className="flex gap-4">
              <Button onClick={() => navigate('/my-passes')}>
                View My Passes
              </Button>
              <Button variant="outline" onClick={() => navigate('/dashboard')}>
                Go to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <div className="container mx-auto p-6 max-w-2xl">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Ticket className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Active Cards</h3>
            <p className="text-muted-foreground text-center mb-4">
              Please register an active card first to apply for a pass
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const selectedPricing = PASS_PRICING[passType];

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Apply for Travel Pass</CardTitle>
          <CardDescription>
            Get unlimited travel with daily, weekly, or monthly passes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="card">Select Card *</Label>
                <Select value={selectedCard} onValueChange={setSelectedCard} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a card" />
                  </SelectTrigger>
                  <SelectContent>
                    {cards.map((card) => (
                      <SelectItem key={card.id} value={card.id}>
                        {card.card_number} - {card.card_type.replace('_', ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="passType">Pass Type *</Label>
                <Select value={passType} onValueChange={(value) => setPassType(value as PassType)} required>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily Pass - ₹{PASS_PRICING.daily.price}</SelectItem>
                    <SelectItem value="weekly">Weekly Pass - ₹{PASS_PRICING.weekly.price}</SelectItem>
                    <SelectItem value="monthly">Monthly Pass - ₹{PASS_PRICING.monthly.price}</SelectItem>
                    <SelectItem value="student">Student Pass - ₹{PASS_PRICING.student.price}</SelectItem>
                    <SelectItem value="senior_citizen">Senior Citizen Pass - ₹{PASS_PRICING.senior_citizen.price}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="routeZone">Route/Zone *</Label>
                <Select value={routeZone} onValueChange={setRouteZone} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select route or zone" />
                  </SelectTrigger>
                  <SelectContent>
                    {ROUTE_ZONES.map((zone) => (
                      <SelectItem key={zone.id} value={zone.id}>
                        {zone.name} - {zone.description}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
              <h4 className="font-semibold mb-2">Pass Details</h4>
              <div className="space-y-1 text-sm">
                <p><span className="text-muted-foreground">Duration:</span> {selectedPricing.duration}</p>
                <p><span className="text-muted-foreground">Description:</span> {selectedPricing.description}</p>
                <p className="text-lg font-bold mt-2">Total: ₹{selectedPricing.price}</p>
              </div>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Important Information</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Pass will be activated after successful payment</li>
                <li>• Pass is non-transferable and linked to your card</li>
                <li>• Validity starts from the date of activation</li>
                <li>• Refunds are not available after activation</li>
              </ul>
            </div>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1" disabled={submitting}>
                {submitting ? 'Processing...' : 'Proceed to Payment'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/dashboard')}
                disabled={submitting}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
