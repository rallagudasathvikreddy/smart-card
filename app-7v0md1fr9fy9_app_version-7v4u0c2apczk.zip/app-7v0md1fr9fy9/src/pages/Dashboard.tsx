import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/components/auth/AuthProvider';
import { cardsApi, transactionsApi, passesApi } from '@/db/api';
import type { Card as CardType, Transaction, Pass } from '@/types/types';
import { CreditCard, Wallet, Ticket, Plus, ArrowRight, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function Dashboard() {
  const { user, profile } = useAuth();
  const [cards, setCards] = useState<CardType[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [passes, setPasses] = useState<Pass[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const [cardsData, transactionsData, passesData] = await Promise.all([
        cardsApi.getUserCards(user.id),
        transactionsApi.getUserTransactions(user.id, 5),
        passesApi.getUserPasses(user.id),
      ]);
      
      setCards(cardsData);
      setTransactions(transactionsData);
      setPasses(passesData);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalBalance = cards.reduce((sum, card) => sum + Number(card.balance), 0);
  const activeCards = cards.filter((card) => card.status === 'active').length;
  const activePasses = passes.filter((pass) => pass.status === 'active').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">
          Welcome back, {profile?.full_name || 'User'}!
        </h1>
        <p className="text-muted-foreground mt-2">
          Manage your smart cards, check balances, and apply for passes
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalBalance.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Across {activeCards} active {activeCards === 1 ? 'card' : 'cards'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Cards</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCards}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {cards.length} total {cards.length === 1 ? 'card' : 'cards'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Passes</CardTitle>
            <Ticket className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activePasses}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {passes.length} total {passes.length === 1 ? 'pass' : 'passes'}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <Link to="/register-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Plus className="h-6 w-6 text-primary" />
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground" />
              </div>
              <CardTitle className="mt-4">Register New Card</CardTitle>
              <CardDescription>
                Apply for a new smart card for public transport
              </CardDescription>
            </CardHeader>
          </Link>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <Link to="/balance">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="p-2 bg-secondary/10 rounded-lg">
                  <Wallet className="h-6 w-6 text-secondary" />
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground" />
              </div>
              <CardTitle className="mt-4">Check Balance & Recharge</CardTitle>
              <CardDescription>
                View balance and recharge your smart card
              </CardDescription>
            </CardHeader>
          </Link>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <Link to="/apply-pass">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="p-2 bg-accent/10 rounded-lg">
                  <Ticket className="h-6 w-6 text-accent" />
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground" />
              </div>
              <CardTitle className="mt-4">Apply for Pass</CardTitle>
              <CardDescription>
                Get daily, weekly, or monthly travel passes
              </CardDescription>
            </CardHeader>
          </Link>
        </Card>
      </div>

      {transactions.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Your latest card activities</CardDescription>
              </div>
              <Link to="/balance">
                <Button variant="ghost" size="sm">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`p-2 rounded-full ${
                        transaction.type === 'recharge'
                          ? 'bg-secondary/10'
                          : transaction.type === 'deduction'
                            ? 'bg-destructive/10'
                            : 'bg-primary/10'
                      }`}
                    >
                      <TrendingUp
                        className={`h-4 w-4 ${
                          transaction.type === 'recharge'
                            ? 'text-secondary'
                            : transaction.type === 'deduction'
                              ? 'text-destructive'
                              : 'text-primary'
                        }`}
                      />
                    </div>
                    <div>
                      <p className="font-medium">
                        {transaction.description || transaction.type}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(transaction.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`font-semibold ${
                        transaction.type === 'recharge'
                          ? 'text-secondary'
                          : transaction.type === 'deduction'
                            ? 'text-destructive'
                            : 'text-primary'
                      }`}
                    >
                      {transaction.type === 'recharge' ? '+' : '-'}₹
                      {Number(transaction.amount).toFixed(2)}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Balance: ₹{Number(transaction.balance_after).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {cards.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CreditCard className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Cards Yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Register your first smart card to get started
            </p>
            <Link to="/register-card">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Register Card
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
