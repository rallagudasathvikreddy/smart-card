import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAuth } from '@/components/auth/AuthProvider';
import { cardsApi, transactionsApi } from '@/db/api';
import { supabase } from '@/db/supabase';
import { useToast } from '@/hooks/use-toast';
import type { Card as CardType, Transaction } from '@/types/types';
import { Wallet, CreditCard, TrendingUp, Plus } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const RECHARGE_AMOUNTS = [100, 200, 500, 1000, 2000, 5000];

export default function Balance() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [cards, setCards] = useState<CardType[]>([]);
  const [selectedCard, setSelectedCard] = useState<CardType | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [rechargeAmount, setRechargeAmount] = useState('');
  const [customAmount, setCustomAmount] = useState('');
  const [recharging, setRecharging] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    if (user) {
      loadCards();
    }
  }, [user]);

  useEffect(() => {
    if (selectedCard) {
      loadTransactions(selectedCard.id);
    }
  }, [selectedCard]);

  const loadCards = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const cardsData = await cardsApi.getUserCards(user.id);
      setCards(cardsData);
      if (cardsData.length > 0 && !selectedCard) {
        setSelectedCard(cardsData[0]);
      }
    } catch (error) {
      console.error('Error loading cards:', error);
      toast({
        title: 'Error',
        description: 'Failed to load cards',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const loadTransactions = async (cardId: string) => {
    try {
      const transactionsData = await transactionsApi.getCardTransactions(cardId);
      setTransactions(transactionsData);
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  };

  const handleRecharge = async () => {
    if (!selectedCard || !user) return;
    
    const amount = rechargeAmount === 'custom' ? Number(customAmount) : Number(rechargeAmount);
    
    if (!amount || amount <= 0) {
      toast({
        title: 'Invalid Amount',
        description: 'Please enter a valid recharge amount',
        variant: 'destructive',
      });
      return;
    }

    setRecharging(true);
    try {
      const { data, error } = await supabase.functions.invoke('create_stripe_checkout', {
        body: {
          items: [
            {
              name: `Card Recharge - ${selectedCard.card_number}`,
              price: amount,
              quantity: 1,
            },
          ],
          currency: 'inr',
        },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to create checkout session');
      }

      if (data?.url) {
        window.open(data.url, '_blank');
        setDialogOpen(false);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to initiate recharge',
        variant: 'destructive',
      });
    } finally {
      setRecharging(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  if (cards.length === 0) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CreditCard className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Cards Found</h3>
            <p className="text-muted-foreground text-center mb-4">
              Please register a card first to check balance and recharge
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Card Balance & Recharge</h1>
        <p className="text-muted-foreground mt-2">
          Check your balance and recharge your smart card
        </p>
      </div>

      {cards.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Select Card</CardTitle>
          </CardHeader>
          <CardContent>
            <Select
              value={selectedCard?.id}
              onValueChange={(value) => {
                const card = cards.find((c) => c.id === value);
                if (card) setSelectedCard(card);
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {cards.map((card) => (
                  <SelectItem key={card.id} value={card.id}>
                    {card.card_number} - {card.card_type.replace('_', ' ')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      )}

      {selectedCard && (
        <>
          <div className="bg-gradient-to-br from-primary to-primary-glow p-8 rounded-xl text-primary-foreground">
            <div className="flex items-center justify-between mb-6">
              <span className="text-sm opacity-90">Smart Card</span>
              <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground">
                {selectedCard.status}
              </Badge>
            </div>
            <div className="text-3xl font-mono tracking-wider mb-6">
              {selectedCard.card_number.match(/.{1,4}/g)?.join(' ')}
            </div>
            <div className="flex justify-between items-end">
              <div>
                <div className="text-sm opacity-75 mb-1">Current Balance</div>
                <div className="text-4xl font-bold">₹{Number(selectedCard.balance).toFixed(2)}</div>
              </div>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" variant="secondary">
                    <Plus className="mr-2 h-5 w-5" />
                    Recharge
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Recharge Card</DialogTitle>
                    <DialogDescription>
                      Select or enter the amount you want to recharge
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-3">
                      {RECHARGE_AMOUNTS.map((amount) => (
                        <Button
                          key={amount}
                          variant={rechargeAmount === String(amount) ? 'default' : 'outline'}
                          onClick={() => {
                            setRechargeAmount(String(amount));
                            setCustomAmount('');
                          }}
                        >
                          ₹{amount}
                        </Button>
                      ))}
                    </div>
                    <div className="space-y-2">
                      <Label>Custom Amount</Label>
                      <Input
                        type="number"
                        placeholder="Enter custom amount"
                        value={customAmount}
                        onChange={(e) => {
                          setCustomAmount(e.target.value);
                          setRechargeAmount('custom');
                        }}
                      />
                    </div>
                    <Button className="w-full" onClick={handleRecharge} disabled={recharging}>
                      {recharging ? 'Processing...' : 'Proceed to Payment'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>Recent transactions for this card</CardDescription>
            </CardHeader>
            <CardContent>
              {transactions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No transactions yet
                </div>
              ) : (
                <div className="space-y-3">
                  {transactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="flex items-center gap-4">
                        <div
                          className={`p-2 rounded-full ${
                            transaction.type === 'recharge'
                              ? 'bg-secondary/10'
                              : 'bg-destructive/10'
                          }`}
                        >
                          <TrendingUp
                            className={`h-4 w-4 ${
                              transaction.type === 'recharge'
                                ? 'text-secondary'
                                : 'text-destructive'
                            }`}
                          />
                        </div>
                        <div>
                          <p className="font-medium capitalize">
                            {transaction.description || transaction.type}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(transaction.created_at).toLocaleString()}
                          </p>
                          {transaction.location && (
                            <p className="text-xs text-muted-foreground">
                              Location: {transaction.location}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p
                          className={`font-semibold ${
                            transaction.type === 'recharge'
                              ? 'text-secondary'
                              : 'text-destructive'
                          }`}
                        >
                          {transaction.type === 'recharge' ? '+' : '-'}₹
                          {Number(transaction.amount).toFixed(2)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Balance: ₹{Number(transaction.balance_after).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
