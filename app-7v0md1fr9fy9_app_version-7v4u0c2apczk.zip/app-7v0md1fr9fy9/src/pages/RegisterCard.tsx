import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/components/auth/AuthProvider';
import { adminApi, profilesApi } from '@/db/api';
import { useToast } from '@/hooks/use-toast';
import type { CardType } from '@/types/types';
import { CreditCard, CheckCircle2 } from 'lucide-react';

export default function RegisterCard() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [cardNumber, setCardNumber] = useState('');

  const [formData, setFormData] = useState({
    fullName: profile?.full_name || '',
    phone: profile?.phone || '',
    idProofType: profile?.id_proof_type || '',
    idProofNumber: profile?.id_proof_number || '',
    cardType: 'general' as CardType,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      if (
        formData.fullName !== profile?.full_name ||
        formData.phone !== profile?.phone ||
        formData.idProofType !== profile?.id_proof_type ||
        formData.idProofNumber !== profile?.id_proof_number
      ) {
        await profilesApi.updateProfile(user.id, {
          full_name: formData.fullName,
          phone: formData.phone,
          id_proof_type: formData.idProofType,
          id_proof_number: formData.idProofNumber,
        });
        await refreshProfile();
      }

      const card = await adminApi.createCard(user.id, formData.cardType);
      
      setCardNumber(card.card_number);
      setSuccess(true);
      
      toast({
        title: 'Success',
        description: 'Your smart card has been registered successfully!',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to register card',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="container mx-auto p-6 max-w-2xl">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="p-4 bg-secondary/10 rounded-full mb-6">
              <CheckCircle2 className="h-16 w-16 text-secondary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Card Registered Successfully!</h2>
            <p className="text-muted-foreground text-center mb-6">
              Your smart card has been created and is ready to use
            </p>
            
            <div className="bg-gradient-to-br from-primary to-primary-glow p-6 rounded-xl text-primary-foreground w-full max-w-sm mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm opacity-90">Smart Card</span>
                <CreditCard className="h-6 w-6" />
              </div>
              <div className="text-2xl font-mono tracking-wider mb-4">
                {cardNumber.match(/.{1,4}/g)?.join(' ')}
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <div className="text-xs opacity-75">Card Holder</div>
                  <div className="font-medium">{formData.fullName}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs opacity-75">Type</div>
                  <div className="font-medium capitalize">{formData.cardType.replace('_', ' ')}</div>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <Button onClick={() => navigate('/balance')}>
                Check Balance
              </Button>
              <Button variant="outline" onClick={() => navigate('/dashboard')}>
                Go to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Register New Smart Card</CardTitle>
          <CardDescription>
            Fill in your details to register for a new public transport smart card
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="idProofType">ID Proof Type *</Label>
                <Select
                  value={formData.idProofType}
                  onValueChange={(value) => setFormData({ ...formData, idProofType: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select ID proof type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aadhar">Aadhar Card</SelectItem>
                    <SelectItem value="pan">PAN Card</SelectItem>
                    <SelectItem value="driving_license">Driving License</SelectItem>
                    <SelectItem value="voter_id">Voter ID</SelectItem>
                    <SelectItem value="passport">Passport</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="idProofNumber">ID Proof Number *</Label>
                <Input
                  id="idProofNumber"
                  value={formData.idProofNumber}
                  onChange={(e) => setFormData({ ...formData, idProofNumber: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cardType">Card Type *</Label>
                <Select
                  value={formData.cardType}
                  onValueChange={(value) => setFormData({ ...formData, cardType: value as CardType })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Commuter</SelectItem>
                    <SelectItem value="student">Student (Discounted)</SelectItem>
                    <SelectItem value="senior_citizen">Senior Citizen (Discounted)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Important Information</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Card will be issued digitally and activated immediately</li>
                <li>• Initial balance will be ₹0, please recharge to start using</li>
                <li>• Card is valid for 5 years from the date of issue</li>
                <li>• Keep your card number safe for future reference</li>
              </ul>
            </div>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1" disabled={loading}>
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground mr-2" />
                    Registering...
                  </>
                ) : (
                  'Register Card'
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/dashboard')}
                disabled={loading}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
