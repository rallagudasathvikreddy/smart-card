import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/db/supabase';
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';

export default function PaymentSuccess() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (sessionId) {
      verifyPayment(sessionId);
    } else {
      setStatus('error');
      setMessage('No session ID found');
    }
  }, [searchParams]);

  const verifyPayment = async (sessionId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('verify_stripe_payment', {
        body: { sessionId },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || 'Failed to verify payment');
      }

      if (data?.verified) {
        setStatus('success');
        setMessage('Payment completed successfully!');
      } else {
        setStatus('error');
        setMessage('Payment verification failed');
      }
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Failed to verify payment');
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          {status === 'loading' && (
            <>
              <Loader2 className="h-16 w-16 text-primary animate-spin mb-6" />
              <h2 className="text-2xl font-bold mb-2">Verifying Payment...</h2>
              <p className="text-muted-foreground text-center">
                Please wait while we confirm your payment
              </p>
            </>
          )}

          {status === 'success' && (
            <>
              <div className="p-4 bg-secondary/10 rounded-full mb-6">
                <CheckCircle2 className="h-16 w-16 text-secondary" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
              <p className="text-muted-foreground text-center mb-6">{message}</p>
              <div className="flex gap-4">
                <Button onClick={() => navigate('/balance')}>
                  Check Balance
                </Button>
                <Button variant="outline" onClick={() => navigate('/dashboard')}>
                  Go to Dashboard
                </Button>
              </div>
            </>
          )}

          {status === 'error' && (
            <>
              <div className="p-4 bg-destructive/10 rounded-full mb-6">
                <XCircle className="h-16 w-16 text-destructive" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Payment Failed</h2>
              <p className="text-muted-foreground text-center mb-6">{message}</p>
              <div className="flex gap-4">
                <Button onClick={() => navigate('/balance')}>
                  Try Again
                </Button>
                <Button variant="outline" onClick={() => navigate('/dashboard')}>
                  Go to Dashboard
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
