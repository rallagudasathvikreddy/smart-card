import { supabase } from './supabase';
import type {
  Profile,
  Card,
  Transaction,
  Pass,
  Order,
  UpdateCardBalanceResult,
  TransactionType,
  PassStatus,
  CardType,
} from '@/types/types';

export const profilesApi = {
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    if (!data) throw new Error('Profile not found');
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};

export const cardsApi = {
  async getUserCards(userId: string): Promise<Card[]> {
    const { data, error } = await supabase
      .from('cards')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getCardById(cardId: string): Promise<Card | null> {
    const { data, error } = await supabase
      .from('cards')
      .select('*')
      .eq('id', cardId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getCardByNumber(cardNumber: string): Promise<Card | null> {
    const { data, error } = await supabase
      .from('cards')
      .select('*')
      .eq('card_number', cardNumber)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getAllCards(): Promise<Card[]> {
    const { data, error } = await supabase
      .from('cards')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async generateCardNumber(): Promise<string> {
    const { data, error } = await supabase.rpc('generate_card_number');
    if (error) throw error;
    return data;
  },
};

export const transactionsApi = {
  async getCardTransactions(cardId: string, limit = 50): Promise<Transaction[]> {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('card_id', cardId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getUserTransactions(userId: string, limit = 50): Promise<Transaction[]> {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getAllTransactions(limit = 100): Promise<Transaction[]> {
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async updateCardBalance(
    cardId: string,
    userId: string,
    type: TransactionType,
    amount: number,
    description?: string,
    location?: string
  ): Promise<UpdateCardBalanceResult> {
    const { data, error } = await supabase.rpc('update_card_balance', {
      p_card_id: cardId,
      p_user_id: userId,
      p_type: type,
      p_amount: amount,
      p_description: description || null,
      p_location: location || null,
    });
    
    if (error) throw error;
    return data;
  },
};

export const passesApi = {
  async getUserPasses(userId: string): Promise<Pass[]> {
    const { data, error } = await supabase
      .from('passes')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getPassById(passId: string): Promise<Pass | null> {
    const { data, error } = await supabase
      .from('passes')
      .select('*')
      .eq('id', passId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async createPass(pass: Omit<Pass, 'id' | 'created_at' | 'updated_at'>): Promise<Pass> {
    const { data, error } = await supabase
      .from('passes')
      .insert(pass)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    if (!data) throw new Error('Failed to create pass');
    return data;
  },

  async updatePassStatus(passId: string, status: PassStatus): Promise<Pass> {
    const { data, error } = await supabase
      .from('passes')
      .update({ status })
      .eq('id', passId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    if (!data) throw new Error('Pass not found');
    return data;
  },

  async getAllPasses(): Promise<Pass[]> {
    const { data, error } = await supabase
      .from('passes')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};

export const ordersApi = {
  async getUserOrders(userId: string): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getOrderById(orderId: string): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getOrderBySessionId(sessionId: string): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('stripe_session_id', sessionId)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  async getAllOrders(): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },
};

export const storageApi = {
  async uploadDocument(
    userId: string,
    file: File,
    folder: string = 'documents'
  ): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${folder}/${Date.now()}.${fileExt}`;
    
    const { error: uploadError } = await supabase.storage
      .from('app-7v0md1fr9fy9_documents')
      .upload(fileName, file);
    
    if (uploadError) throw uploadError;
    
    const { data } = supabase.storage
      .from('app-7v0md1fr9fy9_documents')
      .getPublicUrl(fileName);
    
    return data.publicUrl;
  },

  async deleteDocument(filePath: string): Promise<void> {
    const { error } = await supabase.storage
      .from('app-7v0md1fr9fy9_documents')
      .remove([filePath]);
    
    if (error) throw error;
  },
};

export const adminApi = {
  async createCard(
    userId: string,
    cardType: CardType,
    expiryYears: number = 5
  ): Promise<Card> {
    const cardNumber = await cardsApi.generateCardNumber();
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + expiryYears);
    
    const { data, error } = await supabase
      .from('cards')
      .insert({
        user_id: userId,
        card_number: cardNumber,
        card_type: cardType,
        balance: 0,
        status: 'active',
        expiry_date: expiryDate.toISOString(),
      })
      .select()
      .maybeSingle();
    
    if (error) throw error;
    if (!data) throw new Error('Failed to create card');
    return data;
  },

  async updateCardStatus(cardId: string, status: string): Promise<Card> {
    const { data, error } = await supabase
      .from('cards')
      .update({ status })
      .eq('id', cardId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    if (!data) throw new Error('Card not found');
    return data;
  },

  async updateUserRole(userId: string, role: string): Promise<Profile> {
    const { data, error } = await supabase
      .from('profiles')
      .update({ role })
      .eq('id', userId)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    if (!data) throw new Error('Profile not found');
    return data;
  },
};
