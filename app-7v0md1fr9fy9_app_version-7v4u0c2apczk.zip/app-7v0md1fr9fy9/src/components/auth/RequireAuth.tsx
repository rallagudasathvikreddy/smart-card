import { useEffect, type ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from './AuthProvider';

interface RequireAuthProps {
  children: ReactNode;
  whiteList?: string[];
}

export function RequireAuth({ children, whiteList = ['/login'] }: RequireAuthProps) {
  const { user, loading } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      const isWhitelisted = whiteList.some((path) => {
        if (path.endsWith('/*')) {
          return location.pathname.startsWith(path.slice(0, -2));
        }
        return location.pathname === path;
      });

      if (!isWhitelisted) {
        navigate('/login', { state: { from: location.pathname }, replace: true });
      }
    }
  }, [user, loading, location, navigate, whiteList]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return <>{children}</>;
}
