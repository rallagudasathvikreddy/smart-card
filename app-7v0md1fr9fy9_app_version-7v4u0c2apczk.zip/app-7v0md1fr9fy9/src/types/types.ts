export type UserRole = 'user' | 'admin';
export type CardType = 'general' | 'student' | 'senior_citizen';
export type CardStatus = 'active' | 'blocked' | 'expired';
export type TransactionType = 'recharge' | 'deduction' | 'refund';
export type PassType = 'daily' | 'weekly' | 'monthly' | 'student' | 'senior_citizen';
export type PassStatus = 'pending' | 'active' | 'expired' | 'cancelled';
export type OrderStatus = 'pending' | 'completed' | 'cancelled' | 'refunded';

export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  phone: string | null;
  id_proof_type: string | null;
  id_proof_number: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Card {
  id: string;
  user_id: string;
  card_number: string;
  card_type: CardType;
  balance: number;
  status: CardStatus;
  issued_date: string;
  expiry_date: string;
  created_at: string;
  updated_at: string;
}

export interface Transaction {
  id: string;
  card_id: string;
  user_id: string;
  type: TransactionType;
  amount: number;
  balance_after: number;
  description: string | null;
  location: string | null;
  created_at: string;
}

export interface Pass {
  id: string;
  user_id: string;
  card_id: string | null;
  pass_type: PassType;
  route_zone: string;
  price: number;
  status: PassStatus;
  start_date: string | null;
  end_date: string | null;
  document_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  user_id: string | null;
  items: OrderItem[];
  total_amount: number;
  currency: string;
  status: OrderStatus;
  stripe_session_id: string | null;
  stripe_payment_intent_id: string | null;
  customer_email: string | null;
  customer_name: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  name: string;
  price: number;
  quantity: number;
  image_url?: string;
}

export interface UpdateCardBalanceResult {
  transaction_id: string;
  previous_balance: number;
  new_balance: number;
}

export interface PassPricing {
  type: PassType;
  duration: string;
  price: number;
  description: string;
}

export interface RouteZone {
  id: string;
  name: string;
  description: string;
}
