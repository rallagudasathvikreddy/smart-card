import type { ReactNode } from 'react';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import RegisterCard from './pages/RegisterCard';
import Balance from './pages/Balance';
import ApplyPass from './pages/ApplyPass';
import MyPasses from './pages/MyPasses';
import PaymentSuccess from './pages/PaymentSuccess';
import AdminDashboard from './pages/AdminDashboard';
import NotFound from './pages/NotFound';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <Dashboard />,
    visible: true,
  },
  {
    name: 'Register Card',
    path: '/register-card',
    element: <RegisterCard />,
    visible: true,
  },
  {
    name: 'Balance & Recharge',
    path: '/balance',
    element: <Balance />,
    visible: true,
  },
  {
    name: 'Apply for Pass',
    path: '/apply-pass',
    element: <ApplyPass />,
    visible: true,
  },
  {
    name: 'My Passes',
    path: '/my-passes',
    element: <MyPasses />,
    visible: true,
  },
  {
    name: 'Admin Dashboard',
    path: '/admin',
    element: <AdminDashboard />,
    visible: false,
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false,
  },
  {
    name: 'Payment Success',
    path: '/payment-success',
    element: <PaymentSuccess />,
    visible: false,
  },
  {
    name: 'Not Found',
    path: '*',
    element: <NotFound />,
    visible: false,
  },
];

export default routes;