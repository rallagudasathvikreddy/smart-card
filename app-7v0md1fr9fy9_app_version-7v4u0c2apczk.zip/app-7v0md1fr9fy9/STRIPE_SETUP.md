# Stripe Payment Integration Setup Guide

## Overview

The Hyderabad Smart Card Portal uses Stripe for secure payment processing. This guide will help you configure Stripe to enable recharge and pass purchase features.

## Prerequisites

- A Stripe account (sign up at https://stripe.com)
- Access to your Supabase project dashboard
- Admin access to the Hyderabad Smart Card Portal

## Step-by-Step Setup

### Step 1: Create a Stripe Account

1. Go to https://stripe.com
2. Click **Sign Up** or **Start now**
3. Fill in your business details:
   - Business name: "Hyderabad Smart Card Portal" or your organization name
   - Country: India
   - Business type: Government/Public Service
4. Complete the registration process
5. Verify your email address

### Step 2: Get Your Stripe API Keys

#### For Testing (Test Mode)

1. Log in to your Stripe Dashboard
2. Make sure you're in **Test mode** (toggle in the top right)
3. Navigate to **Developers** → **API keys**
4. You'll see two keys:
   - **Publishable key**: Starts with `pk_test_...` (not needed for this setup)
   - **Secret key**: Starts with `sk_test_...` (this is what you need)
5. Click **Reveal test key** next to the Secret key
6. Copy the secret key (starts with `sk_test_`)

#### For Production (Live Mode)

1. Complete your Stripe account activation:
   - Provide business details
   - Add bank account information
   - Complete identity verification
2. Switch to **Live mode** (toggle in the top right)
3. Navigate to **Developers** → **API keys**
4. Copy the **Secret key** (starts with `sk_live_`)

**Important**: Never share your secret key or commit it to version control!

### Step 3: Add Stripe Secret Key to Supabase

1. Go to your Supabase Dashboard: https://supabase.com/dashboard
2. Select your project: **hyderabad-smart-card** (or your project name)
3. In the left sidebar, click **Project Settings** (gear icon at bottom)
4. Click **Edge Functions** in the settings menu
5. Scroll down to **Secrets** section
6. Click **Add new secret** button
7. Enter the secret details:
   - **Name**: `STRIPE_SECRET_KEY` (must be exactly this)
   - **Value**: Paste your Stripe secret key (e.g., `sk_test_...` or `sk_live_...`)
8. Click **Save** or **Add secret**

### Step 4: Verify the Configuration

1. Log in to your Hyderabad Smart Card Portal
2. Register a card if you haven't already
3. Go to **Balance & Recharge**
4. Click **Recharge** and select an amount
5. Click **Proceed to Payment**
6. You should be redirected to Stripe's checkout page
7. Complete a test payment (use test card numbers in test mode)
8. Verify you're redirected back and balance is updated

## Test Card Numbers (Test Mode Only)

When using Stripe in test mode, use these card numbers:

### Successful Payments
- **Card Number**: 4242 4242 4242 4242
- **Expiry**: Any future date (e.g., 12/34)
- **CVC**: Any 3 digits (e.g., 123)
- **ZIP**: Any 5 digits (e.g., 12345)

### Failed Payments (for testing error handling)
- **Card Declined**: 4000 0000 0000 0002
- **Insufficient Funds**: 4000 0000 0000 9995
- **Expired Card**: 4000 0000 0000 0069

### Indian Payment Methods (Test Mode)
- **UPI**: Use test UPI ID: `success@razorpay`
- **Net Banking**: Select any bank and use test credentials
- **Cards**: Use the test card numbers above

## Stripe Dashboard Overview

### Key Sections

1. **Home**: Overview of your payments and balance
2. **Payments**: View all payment transactions
3. **Customers**: See customer information (auto-created)
4. **Products**: Not used in this integration
5. **Developers**: Access API keys and webhooks

### Monitoring Payments

1. Go to **Payments** in your Stripe Dashboard
2. You'll see all transactions with:
   - Amount
   - Status (Succeeded, Failed, Pending)
   - Customer email
   - Date and time
   - Payment method
3. Click on any payment to see full details
4. You can issue refunds from here if needed

### Understanding Payment Flow

1. **User initiates payment** → Portal creates order in database
2. **Portal calls Edge Function** → Creates Stripe checkout session
3. **User redirected to Stripe** → Completes payment on Stripe's secure page
4. **Payment successful** → Stripe redirects back to portal
5. **Portal verifies payment** → Calls verification Edge Function
6. **Balance updated** → User sees updated balance

## Security Best Practices

### DO:
- ✅ Keep your secret key confidential
- ✅ Use test mode for development and testing
- ✅ Switch to live mode only when ready for production
- ✅ Store secret key in Supabase Edge Function secrets
- ✅ Monitor your Stripe dashboard regularly
- ✅ Enable two-factor authentication on your Stripe account
- ✅ Set up email notifications for payments

### DON'T:
- ❌ Share your secret key with anyone
- ❌ Commit secret key to Git or version control
- ❌ Use live mode keys for testing
- ❌ Store secret key in frontend code
- ❌ Expose secret key in browser console
- ❌ Use the same key across multiple projects

## Troubleshooting

### Error: "STRIPE_SECRET_KEY not configured"

**Solution**: 
- Verify you added the secret to Supabase Edge Functions
- Check the secret name is exactly `STRIPE_SECRET_KEY`
- Redeploy the Edge Functions after adding the secret

### Error: "Invalid API Key"

**Solution**:
- Check you copied the complete secret key
- Ensure no extra spaces before/after the key
- Verify you're using the correct mode (test vs live)
- Generate a new secret key if needed

### Payment succeeds but balance not updated

**Solution**:
- Check the verify_stripe_payment Edge Function logs
- Verify the order was created in the database
- Check if the card exists and belongs to the user
- Look for errors in browser console

### Redirect fails after payment

**Solution**:
- Check your success_url and cancel_url in Edge Function
- Verify the domain is correct
- Check browser console for errors
- Ensure payment-success page exists

## Currency Configuration

The system is configured for Indian Rupees (INR) by default.

To change currency:
1. Edit `/workspace/app-7v0md1fr9fy9/supabase/functions/create_stripe_checkout/index.ts`
2. Find the line: `currency: request.currency || 'inr'`
3. Change `'inr'` to your desired currency code (e.g., `'usd'`, `'eur'`, `'gbp'`)
4. Redeploy the Edge Function

**Supported currencies**: https://stripe.com/docs/currencies

## Payment Methods Configuration

By default, the system accepts card payments. To enable additional payment methods:

1. Edit `/workspace/app-7v0md1fr9fy9/supabase/functions/create_stripe_checkout/index.ts`
2. Find: `payment_method_types: paymentMethods`
3. The default is `['card']`
4. Add more methods: `['card', 'upi', 'netbanking', 'wallet']`
5. Redeploy the Edge Function

**Note**: Some payment methods are region-specific. Check Stripe documentation for availability in your country.

## Going Live Checklist

Before switching to live mode:

- [ ] Complete Stripe account activation
- [ ] Add bank account for payouts
- [ ] Verify business details
- [ ] Test all payment flows in test mode
- [ ] Update STRIPE_SECRET_KEY with live key
- [ ] Test with real card (small amount)
- [ ] Set up webhook endpoints (optional)
- [ ] Configure email receipts in Stripe
- [ ] Enable fraud detection in Stripe
- [ ] Set up refund policy
- [ ] Train support team on payment issues
- [ ] Monitor first few transactions closely

## Support and Resources

### Stripe Resources
- Documentation: https://stripe.com/docs
- API Reference: https://stripe.com/docs/api
- Support: https://support.stripe.com
- Status Page: https://status.stripe.com

### Common Issues
- Payment declined: Usually a card issue, ask user to try another card
- 3D Secure: Some cards require additional authentication
- International cards: May be blocked, enable in Stripe settings
- Refunds: Take 5-7 business days to appear in customer's account

### Getting Help
- Stripe Support: Available 24/7 via dashboard
- Email: support@stripe.com
- Phone: Available for verified accounts
- Community: https://stripe.com/community

## Cost and Fees

### Stripe Pricing (India)
- **Domestic cards**: 2.9% + ₹2 per transaction
- **International cards**: 3.9% + ₹2 per transaction
- **UPI**: 2% (capped at ₹1,000)
- **Net Banking**: 2.9% + ₹2 per transaction
- **No setup fees or monthly fees**

**Note**: Pricing may vary. Check https://stripe.com/in/pricing for current rates.

## Conclusion

Once configured, the Stripe integration will:
- ✅ Process payments securely
- ✅ Update balances automatically
- ✅ Handle refunds and disputes
- ✅ Provide detailed transaction records
- ✅ Support multiple payment methods
- ✅ Comply with PCI DSS standards

For any issues with Stripe integration, contact your system administrator or refer to the Stripe documentation.

---

**Last Updated**: 2025-01-28
**Version**: 1.0
