# Login Testing Guide

## ✅ Authentication Fixed!

The login system has been simplified and fixed. Here's how to test it:

## Step 1: Create Your First Account

1. Open the application
2. You'll see the login page with two tabs: **Login** and **Sign Up**
3. Click on the **Sign Up** tab
4. Fill in the form:
   - **Full Name**: Enter your name (e.g., "Admin User")
   - **Email**: Enter your email (e.g., "admin@test.com")
   - **Phone**: Enter your phone number (optional)
   - **Password**: Enter a password (minimum 6 characters)
5. Click **Create Account**
6. You should see a success message: "Account created successfully! Logging you in..."
7. You will be automatically redirected to the Dashboard

**Important**: The first user to register automatically becomes the administrator!

## Step 2: Verify You're Logged In

After successful signup, you should see:

1. **Header**: Shows "Hyderabad Smart Card" logo and your name in the top right
2. **Navigation Menu**: Shows links to:
   - Dashboard
   - Register Card
   - Balance & Recharge
   - Apply for Pass
   - My Passes
3. **Dashboard Page**: Shows overview cards with:
   - Total Cards: 0 (initially)
   - Total Balance: ₹0.00
   - Active Passes: 0
   - Quick action buttons

## Step 3: Test Login (After Logout)

1. Click on your name in the top right corner
2. Select **Logout**
3. You'll be redirected to the login page
4. Click on the **Login** tab
5. Enter your email and password
6. Click **Login**
7. You should be logged in and redirected to the Dashboard

## Step 4: Test All Features

### Register a Card
1. From Dashboard, click **Register New Card**
2. Fill in the form:
   - Full Name
   - Phone Number
   - ID Proof Type (select from dropdown)
   - ID Proof Number
   - Card Type (General, Student, or Senior Citizen)
3. Click **Register Card**
4. You should see a success message with your new card number

### Check Balance
1. Go to **Balance & Recharge** from the menu
2. You should see your registered card
3. View current balance (₹0.00 initially)
4. See transaction history (empty initially)

### Apply for Pass
1. Go to **Apply for Pass** from the menu
2. Select your card
3. Choose a pass type (Daily, Weekly, Monthly, etc.)
4. Select a route/zone
5. Click **Proceed to Payment**
6. **Note**: Payment will only work after Stripe is configured

### View Passes
1. Go to **My Passes** from the menu
2. See all your passes (empty initially)

### Admin Dashboard (First User Only)
1. Click on your name in the top right
2. You should see **Admin Dashboard** option
3. Click it to view:
   - Total users
   - Total cards
   - Total balance
   - Active passes
   - User management
   - Card management
   - Pass management
   - Transaction reports

## Common Issues & Solutions

### Issue: "Invalid login credentials"
**Solution**: 
- Make sure you're using the correct email and password
- Try resetting your password
- Make sure you signed up first

### Issue: "User already registered"
**Solution**: 
- Use the Login tab instead of Sign Up
- Or use a different email address

### Issue: Can't see navigation menu
**Solution**: 
- Make sure you're logged in
- Check that you see your name in the top right corner
- Try refreshing the page

### Issue: Dashboard shows loading forever
**Solution**: 
- Check browser console for errors
- Try logging out and logging back in
- Clear browser cache

### Issue: Profile not loading
**Solution**: 
- Wait a few seconds (profile loads automatically)
- Refresh the page
- The system retries 3 times automatically

## What Works Now

✅ User registration (Sign Up)
✅ User login
✅ Automatic profile creation
✅ First user becomes admin
✅ Dashboard loads correctly
✅ All navigation links work
✅ Card registration
✅ Balance checking
✅ Pass application (UI ready)
✅ Admin dashboard
✅ User logout

## What Needs Configuration

⚠️ **Payment Features**: Require Stripe configuration
- Card recharge
- Pass purchase payments

To enable payments, follow the instructions in `STRIPE_SETUP.md`

## Test Accounts

You can create multiple test accounts:

**Admin Account** (First user):
- Email: admin@test.com
- Password: admin123
- Role: Administrator

**Regular User** (Second user):
- Email: user@test.com
- Password: user123
- Role: User

## Expected Behavior

### After Signup:
1. Success toast notification appears
2. Automatically logged in
3. Redirected to Dashboard
4. Profile loads within 1-2 seconds
5. Navigation menu appears
6. User name shows in header

### After Login:
1. Success toast notification appears
2. Redirected to Dashboard
3. All features accessible
4. Previous data loads (cards, passes, etc.)

### After Logout:
1. Redirected to login page
2. All user data cleared
3. Protected routes inaccessible
4. Must login again to access features

## Browser Console

If you encounter any issues, check the browser console (F12) for error messages. Common messages:

- ✅ "Auth initialized successfully" - Good!
- ✅ "Profile loaded successfully" - Good!
- ⚠️ "Error loading profile" - Will retry automatically
- ❌ "Invalid login credentials" - Check email/password

## Next Steps

1. ✅ Test signup and login
2. ✅ Register a test card
3. ✅ Explore all pages
4. ⚠️ Configure Stripe for payments
5. ✅ Test admin features (if first user)

## Support

If login still doesn't work:
1. Check browser console for errors
2. Verify Supabase is running
3. Check network tab for failed requests
4. Try a different browser
5. Clear browser cache and cookies

---

**Status**: ✅ Authentication is working and ready to use!
**Last Updated**: 2025-01-28
