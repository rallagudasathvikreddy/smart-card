# Hyderabad Smart Card Portal - User Guide

## Quick Start Guide

### Step 1: Create Your Account

1. Open the Hyderabad Smart Card Portal
2. Click **Sign Up** tab on the login page
3. Fill in your details:
   - **Full Name**: Your complete name as per ID proof
   - **Email**: Your email address (used for login)
   - **Phone Number**: Your mobile number (optional)
   - **Password**: Choose a strong password (minimum 6 characters)
4. Click **Create Account**
5. You will be automatically logged in and redirected to the dashboard

**Important**: The first person to register becomes the system administrator.

### Step 2: Register Your Smart Card

After logging in, you need to register a smart card:

1. From the **Dashboard**, click **Register New Card**
2. Fill in the registration form:
   - **Full Name**: Your name as per ID proof
   - **Phone Number**: Your contact number
   - **ID Proof Type**: Select from dropdown (Aadhar Card, PAN Card, Driving License, Passport, Voter ID)
   - **ID Proof Number**: Enter your ID number
   - **Card Type**: Choose one:
     - **General Commuter**: For regular passengers
     - **Student**: For students (may require verification)
     - **Senior Citizen**: For senior citizens (60+ years)
3. Click **Register Card**
4. Your card will be issued immediately with:
   - A unique 16-digit card number
   - Initial balance of ₹0
   - Valid for 5 years

### Step 3: Recharge Your Card

To add money to your card:

1. Go to **Balance & Recharge** from the navigation menu
2. If you have multiple cards, select the card you want to recharge
3. View your current balance and recent transactions
4. Click **Recharge** button
5. Choose a recharge amount:
   - Quick options: ₹100, ₹200, ₹500, ₹1000
   - Or enter a custom amount (minimum ₹50)
6. Click **Proceed to Payment**
7. You will be redirected to Stripe's secure payment page
8. Complete the payment using:
   - Credit/Debit Card
   - UPI
   - Net Banking
   - Digital Wallets
9. After successful payment, you'll be redirected back
10. Your card balance will be updated immediately

### Step 4: Apply for a Travel Pass

Travel passes give you unlimited rides for a specific period:

1. Go to **Apply for Pass** from the navigation menu
2. Select the card you want to link the pass to
3. Choose your pass type:
   - **Daily Pass**: ₹50 - Valid for 1 day
   - **Weekly Pass**: ₹300 - Valid for 7 days
   - **Monthly Pass**: ₹1000 - Valid for 30 days
   - **Student Pass**: ₹600 - Valid for 30 days (student cards only)
   - **Senior Citizen Pass**: ₹500 - Valid for 30 days (senior citizen cards only)
4. Select your route or zone (e.g., "Zone A - City Center", "Zone B - Suburbs")
5. Review the pricing and validity
6. Click **Proceed to Payment**
7. Complete payment on Stripe
8. Your pass will be activated immediately after payment

### Step 5: View Your Passes

To manage your travel passes:

1. Go to **My Passes** from the navigation menu
2. View all your passes with:
   - Pass type and status (Active, Pending, Expired, Cancelled)
   - Route/Zone coverage
   - Start and end dates
   - Price paid
3. Active passes show in green
4. Expired passes show in gray

## Features Overview

### Dashboard
Your central hub showing:
- Total number of cards you own
- Combined balance across all cards
- Number of active passes
- Recent transactions
- Quick action buttons for common tasks

### Balance & Recharge
- View real-time card balance
- See complete transaction history
- Filter transactions by type (Recharge, Deduction, Refund)
- Recharge cards online instantly
- Download transaction receipts

### Card Management
- Register multiple cards (family members, backup cards)
- View card details (number, type, status, expiry)
- Check card validity
- Track card usage

### Pass Management
- Apply for various pass types
- View active and expired passes
- Track pass validity dates
- Renew passes before expiry

## Payment Information

### Accepted Payment Methods
- Credit Cards (Visa, Mastercard, American Express)
- Debit Cards
- UPI (Google Pay, PhonePe, Paytm)
- Net Banking
- Digital Wallets

### Payment Security
- All payments processed through Stripe (PCI DSS compliant)
- SSL encryption for all transactions
- No card details stored on our servers
- Instant payment confirmation

### Test Mode (For Testing Only)
If you're testing the system, use these test card numbers:
- **Success**: 4242 4242 4242 4242
- **Decline**: 4000 0000 0000 0002
- **Expiry**: Any future date (e.g., 12/34)
- **CVC**: Any 3 digits (e.g., 123)

## Card Types Explained

### General Commuter Card
- For all regular passengers
- No age restrictions
- Standard pricing for passes
- Can be used on all routes

### Student Card
- For students with valid student ID
- Discounted pass rates
- May require verification
- Valid for 1 year, renewable

### Senior Citizen Card
- For passengers aged 60 and above
- Discounted pass rates
- Requires age proof
- Special priority seating

## Transaction Types

### Recharge
- Adding money to your card
- Minimum: ₹50
- Maximum: ₹10,000 per transaction
- Instant credit to card

### Deduction
- Fare deducted when you travel
- Automatic deduction at entry/exit
- Real-time balance update
- SMS notification for low balance

### Refund
- Money returned to your card
- For cancelled trips or errors
- Processed within 24 hours
- Notification sent via email

## Tips for Best Experience

1. **Keep Minimum Balance**: Maintain at least ₹50 in your card for smooth travel
2. **Buy Passes for Regular Travel**: Monthly passes are more economical for daily commuters
3. **Check Expiry Dates**: Renew passes before they expire to avoid interruption
4. **Save Card Number**: Note down your card number for quick balance checks
5. **Enable Notifications**: Keep email notifications on for transaction alerts
6. **Update Contact Info**: Keep your phone number and email updated

## Troubleshooting

### Cannot Login
- Check your email and password
- Ensure email is verified (if verification is enabled)
- Try resetting your password
- Clear browser cache and cookies

### Payment Failed
- Check your internet connection
- Verify card details are correct
- Ensure sufficient balance in your bank account
- Try a different payment method
- Contact your bank if payment is declined

### Balance Not Updated
- Wait for 2-3 minutes for system sync
- Refresh the page
- Check transaction history for confirmation
- Contact support if issue persists

### Pass Not Activated
- Check payment status in transaction history
- Verify payment was successful
- Wait for 5 minutes for activation
- Contact support with payment reference

## Admin Features (For Administrators Only)

If you are the system administrator, you have additional access:

### Admin Dashboard
- View all registered users
- Monitor all cards in the system
- Track all pass applications
- View complete transaction reports
- Generate system statistics

### User Management
- View user details and roles
- Monitor user activity
- Handle user queries
- Manage user accounts

### Card Management
- View all issued cards
- Check card status and balances
- Handle card-related issues
- Block/unblock cards if needed

### Pass Management
- Approve pass applications
- Verify student/senior citizen documents
- Handle pass renewals
- Cancel passes if needed

### Reports
- Daily transaction reports
- Revenue reports
- User growth statistics
- Popular routes analysis

## Contact Support

For any issues or queries:
- Email: support@hyderabadsmartcard.gov.in
- Phone: 1800-XXX-XXXX (Toll-free)
- Timings: 9:00 AM - 6:00 PM (Mon-Sat)

## Important Notes

1. **Card Validity**: All cards are valid for 5 years from date of issue
2. **Balance Expiry**: Card balance does not expire
3. **Pass Validity**: Passes are non-refundable once activated
4. **Multiple Cards**: You can register multiple cards under one account
5. **Family Cards**: Register separate accounts for family members
6. **Lost Cards**: Report lost cards immediately to block them
7. **Refunds**: Refunds take 5-7 business days to process
8. **Data Privacy**: Your personal information is secure and encrypted

## Frequently Asked Questions

**Q: Can I use one card for multiple people?**
A: No, each card is personal and non-transferable.

**Q: What happens if I lose my card?**
A: Contact support immediately to block the card and transfer balance to a new card.

**Q: Can I get a refund for unused balance?**
A: Yes, contact support with your card details and bank information.

**Q: How do I renew my pass?**
A: Apply for a new pass before the current one expires.

**Q: Can I use my card in other cities?**
A: Currently, cards are valid only for Hyderabad public transport.

**Q: Is there a mobile app?**
A: The web portal is mobile-responsive. A dedicated app is coming soon.

**Q: How do I update my personal information?**
A: Contact support to update your registered details.

**Q: Can I transfer balance between cards?**
A: No, balance transfers are not allowed for security reasons.

---

**Welcome to the future of public transport in Hyderabad!**

For the latest updates, visit: www.hyderabadsmartcard.gov.in
