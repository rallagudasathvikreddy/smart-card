# 🚀 First Time Setup - IMPORTANT!

## ⚠️ Getting "Invalid Login Credentials" Error?

This means you **haven't created an account yet**!

---

## ✅ Follow These Steps (First Time Users)

### Step 1: Open the Application
You'll see the login page with two tabs:
- Login
- Sign Up

### Step 2: Click "Sign Up" Tab ← IMPORTANT!
**Don't use the Login tab yet!** You need to create an account first.

### Step 3: Fill in the Sign Up Form

```
Full Name:     [Enter your name]
Email:         [Enter your email]
Phone:         [Enter your phone - optional]
Password:      [Enter password - min 6 characters]
```

**Example:**
```
Full Name:     Admin User
Email:         admin@test.com
Phone:         9876543210
Password:      admin123
```

### Step 4: Click "Create Account" Button

You should see:
- ✅ Success message: "Account created successfully! Logging you in..."
- ✅ Automatically redirected to Dashboard
- ✅ You're now logged in!

---

## 🎉 Success! You're Now Logged In

You should see:
- **Header** with navigation menu
- **Your name** in the top right corner
- **Dashboard** with overview cards
- **Quick action buttons**

---

## 🔄 For Next Time (After You've Signed Up)

### To Login Again:
1. Open the application
2. Stay on the **"Login"** tab
3. Enter your email and password
4. Click "Login"
5. ✅ Redirected to Dashboard

---

## 🆘 Troubleshooting

### Error: "Invalid login credentials"
**Cause**: You're trying to login without having an account

**Solution**: 
1. Click the **"Sign Up"** tab
2. Create an account first
3. Then you can login

### Error: "User already registered"
**Cause**: You already have an account

**Solution**: 
1. Use the **"Login"** tab instead
2. Enter your existing email and password

### Error: "Password should be at least 6 characters"
**Cause**: Your password is too short

**Solution**: 
1. Use a password with at least 6 characters
2. Example: "admin123" or "password123"

---

## 📋 Checklist

Before trying to login, make sure:
- [ ] I clicked the "Sign Up" tab (not Login)
- [ ] I filled in all required fields
- [ ] My password is at least 6 characters
- [ ] I clicked "Create Account" button
- [ ] I saw the success message
- [ ] I was redirected to Dashboard

---

## 🎯 Quick Summary

### First Time:
```
1. Click "Sign Up" tab
2. Fill in the form
3. Click "Create Account"
4. ✅ You're in!
```

### After That:
```
1. Use "Login" tab
2. Enter email and password
3. Click "Login"
4. ✅ You're in!
```

---

## 💡 Pro Tips

1. **First user becomes admin** - Sign up first to get admin access!
2. **Remember your password** - Write it down if needed
3. **Use a valid email** - In case you need password reset later
4. **Test credentials**: 
   - Email: admin@test.com
   - Password: admin123

---

## ✅ What to Do Right Now

1. Go back to the application
2. Look for the **"Sign Up"** tab
3. Click it
4. Fill in the form
5. Click "Create Account"
6. You'll be automatically logged in and see the Dashboard!

---

**That's it! You're ready to go! 🎉**
