# 🧭 Navigation Guide - Hyderabad Smart Card Portal

## How to Access the Dashboard

### For New Users (First Time)

1. **Open the Application**
   - You'll see the Login page automatically

2. **Create an Account**
   - Click on the **"Sign Up"** tab
   - Fill in your details:
     - Full Name
     - Email
     - Phone Number (optional)
     - Password (minimum 6 characters)
   - Click **"Create Account"** button

3. **Automatic Login**
   - After successful signup, you'll see: "Account created successfully! Logging you in..."
   - You'll be **automatically redirected to the Dashboard** within 1 second
   - No need to login again!

### For Existing Users

1. **Open the Application**
   - You'll see the Login page

2. **Login**
   - Make sure you're on the **"Login"** tab
   - Enter your email
   - Enter your password
   - Click **"Login"** button

3. **Redirected to Dashboard**
   - After successful login, you'll see: "Logged in successfully"
   - You'll be **automatically redirected to the Dashboard**

## Dashboard Overview

Once you reach the Dashboard, you'll see:

### Top Section - Header
- **Logo**: "Hyderabad Smart Card" on the left
- **Navigation Menu**: Links to all pages
- **User Profile**: Your name and profile menu on the right

### Main Content - Overview Cards

**Three Summary Cards:**
1. **Total Cards** 
   - Shows number of cards you've registered
   - Initially shows: 0

2. **Total Balance**
   - Shows combined balance across all cards
   - Initially shows: ₹0.00

3. **Active Passes**
   - Shows number of active travel passes
   - Initially shows: 0

### Quick Actions Section

**Three Action Buttons:**
1. **Register New Card** → Takes you to Card Registration page
2. **Recharge Card** → Takes you to Balance & Recharge page
3. **Apply for Pass** → Takes you to Pass Application page

### Recent Activity Section

Shows your recent transactions (initially empty)

## Navigation Menu (Available from Dashboard)

Click on any menu item in the header to navigate:

### 1. Dashboard (Home Icon)
- **Path**: `/` (root)
- **Purpose**: Overview of your account
- **Shows**: Cards, balance, passes, recent activity

### 2. Register Card
- **Path**: `/register-card`
- **Purpose**: Register a new smart card
- **Action**: Fill form and submit

### 3. Balance & Recharge
- **Path**: `/balance`
- **Purpose**: Check balance and recharge cards
- **Shows**: All your cards with balances and transaction history

### 4. Apply for Pass
- **Path**: `/apply-pass`
- **Purpose**: Apply for travel passes
- **Options**: Daily, Weekly, Monthly, Student, Senior Citizen passes

### 5. My Passes
- **Path**: `/my-passes`
- **Purpose**: View all your passes
- **Shows**: Active, pending, and expired passes

### 6. Admin Dashboard (Admins Only)
- **Path**: `/admin`
- **Purpose**: System administration
- **Access**: Only visible to administrators (first registered user)
- **Location**: Click your name → "Admin Dashboard"

## User Profile Menu

Click on your name in the top right corner to see:

- **Profile** (if implemented)
- **Admin Dashboard** (if you're an admin)
- **Logout**

## Complete User Flow Example

### Scenario: New User Registering First Card

```
1. Open App
   ↓
2. See Login Page
   ↓
3. Click "Sign Up" tab
   ↓
4. Fill registration form
   ↓
5. Click "Create Account"
   ↓
6. ✅ Automatically redirected to Dashboard
   ↓
7. See overview (0 cards, ₹0 balance, 0 passes)
   ↓
8. Click "Register New Card" button
   ↓
9. Fill card registration form
   ↓
10. Submit form
    ↓
11. ✅ Card registered successfully
    ↓
12. Redirected back to Dashboard
    ↓
13. Now shows: 1 card, ₹0 balance
```

### Scenario: Existing User Recharging Card

```
1. Open App
   ↓
2. See Login Page
   ↓
3. Enter email and password
   ↓
4. Click "Login"
   ↓
5. ✅ Automatically redirected to Dashboard
   ↓
6. Click "Balance & Recharge" in menu
   ↓
7. See your cards with balances
   ↓
8. Click "Recharge" button on a card
   ↓
9. Enter amount
   ↓
10. Click "Proceed to Payment"
    ↓
11. Complete payment on Stripe
    ↓
12. ✅ Redirected to Payment Success page
    ↓
13. Balance updated automatically
```

## Navigation Tips

### ✅ Do's
- Use the navigation menu in the header to move between pages
- Click the logo to return to Dashboard anytime
- Use the quick action buttons on Dashboard for common tasks
- Check Dashboard regularly for overview of your account

### ❌ Don'ts
- Don't use browser back button (use navigation menu instead)
- Don't bookmark internal pages (bookmark the home page)
- Don't share your login credentials
- Don't close the browser during payment

## Keyboard Shortcuts

- **Tab**: Navigate between form fields
- **Enter**: Submit forms
- **Esc**: Close dialogs/modals

## Mobile Navigation

On mobile devices:
- Navigation menu collapses into a hamburger menu (☰)
- Click the hamburger icon to see all menu items
- Swipe gestures may work for navigation

## Troubleshooting Navigation

### Issue: Stuck on Login Page
**Solution**: 
- Make sure you entered correct credentials
- Check for error messages
- Try refreshing the page

### Issue: Dashboard Not Loading
**Solution**:
- Wait a few seconds (data is loading)
- Check your internet connection
- Try logging out and back in

### Issue: Can't Find a Page
**Solution**:
- Check the navigation menu in the header
- Return to Dashboard and use quick action buttons
- Some pages (like Admin Dashboard) are only visible to admins

### Issue: Redirected to Login After Being Logged In
**Solution**:
- Your session may have expired
- Login again
- Check "Remember me" option (if available)

## Page Access Rules

### Public Pages (No Login Required)
- ❌ None - All pages require login

### Protected Pages (Login Required)
- ✅ Dashboard
- ✅ Register Card
- ✅ Balance & Recharge
- ✅ Apply for Pass
- ✅ My Passes
- ✅ Payment Success

### Admin-Only Pages
- ✅ Admin Dashboard (only first registered user)

## URL Structure

```
https://your-app-url.com/              → Dashboard
https://your-app-url.com/login         → Login Page
https://your-app-url.com/register-card → Register Card
https://your-app-url.com/balance       → Balance & Recharge
https://your-app-url.com/apply-pass    → Apply for Pass
https://your-app-url.com/my-passes     → My Passes
https://your-app-url.com/admin         → Admin Dashboard
https://your-app-url.com/payment-success → Payment Success
```

## Quick Reference

| Action | Steps |
|--------|-------|
| **Go to Dashboard** | Click logo or "Dashboard" in menu |
| **Register Card** | Dashboard → "Register New Card" button |
| **Check Balance** | Menu → "Balance & Recharge" |
| **Recharge Card** | Balance page → Select card → "Recharge" |
| **Apply for Pass** | Menu → "Apply for Pass" |
| **View Passes** | Menu → "My Passes" |
| **Admin Panel** | Profile menu → "Admin Dashboard" |
| **Logout** | Profile menu → "Logout" |

## Expected Behavior After Login

✅ **Immediately After Login:**
1. Success toast notification appears
2. Login page disappears
3. Dashboard page loads
4. Header with navigation appears
5. Your name shows in top right
6. Overview cards display (may show 0 initially)
7. Quick action buttons are visible

✅ **You Should See:**
- Navigation menu with 5 items
- Your name in the top right corner
- Three overview cards (Cards, Balance, Passes)
- Three quick action buttons
- Recent activity section (may be empty)

❌ **You Should NOT See:**
- Login form
- Sign up form
- Error messages
- Blank page
- Loading spinner forever

## Next Steps After Reaching Dashboard

1. **First Time Users:**
   - Register your first card
   - Explore all menu options
   - Check out the admin dashboard (if you're the first user)

2. **Regular Users:**
   - Check your card balances
   - Recharge if needed
   - Apply for passes
   - View transaction history

3. **Administrators:**
   - Access admin dashboard
   - Monitor system statistics
   - Manage users and cards

---

**Need Help?** Check `TEST_LOGIN.md` for detailed testing instructions.

**Status**: ✅ Navigation is working and ready to use!
