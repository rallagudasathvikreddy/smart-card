# 🚀 Quick Start Guide - Hyderabad Smart Card Portal

## ⚡ Get Started in 3 Steps

### Step 1: Configure Stripe (5 minutes) ⚠️ REQUIRED

Payment features won't work without this!

1. Go to https://stripe.com and create an account
2. Get your Secret Key: Dashboard → Developers → API keys
3. Add to Supabase:
   - Go to https://supabase.com/dashboard
   - Select project: `hyderabad-smart-card`
   - Settings → Edge Functions → Secrets
   - Add: `STRIPE_SECRET_KEY` = your Stripe key
4. Test with card: `4242 4242 4242 4242`

**Detailed guide**: See `STRIPE_SETUP.md`

### Step 2: Create Your Admin Account (2 minutes)

1. Open the application
2. Click **Sign Up**
3. Fill in your details and create account
4. You're now the administrator! 🎉

**Note**: The first user automatically becomes admin.

### Step 3: Test the System (5 minutes)

1. **Register a card**: Dashboard → Register New Card
2. **Recharge**: Balance & Recharge → Recharge → Pay
3. **Apply for pass**: Apply for Pass → Select type → Pay
4. **Check admin**: Profile menu → Admin Dashboard

## 🎯 Key Features

### For Users
- ✅ Register smart cards online
- ✅ Check balance in real-time
- ✅ Recharge cards instantly
- ✅ Apply for travel passes
- ✅ View transaction history

### For Admins
- ✅ View all users and cards
- ✅ Monitor transactions
- ✅ Manage passes
- ✅ System statistics

## 📱 How to Use

### Register a Card
Dashboard → **Register New Card** → Fill form → Submit

### Recharge Card
Balance & Recharge → Select card → **Recharge** → Choose amount → Pay

### Apply for Pass
Apply for Pass → Select card → Choose pass type → Pay

### View Passes
My Passes → See all your passes

### Admin Dashboard
Profile menu → **Admin Dashboard** → View system data

## 💳 Pass Pricing

| Pass Type | Price | Validity |
|-----------|-------|----------|
| Daily | ₹50 | 1 day |
| Weekly | ₹300 | 7 days |
| Monthly | ₹1000 | 30 days |
| Student | ₹600 | 30 days |
| Senior Citizen | ₹500 | 30 days |

## 🧪 Test Mode

Use these test cards (when Stripe is in test mode):

- **Success**: 4242 4242 4242 4242
- **Decline**: 4000 0000 0000 0002
- **Expiry**: Any future date (12/34)
- **CVC**: Any 3 digits (123)

## 🆘 Need Help?

- **Setup**: See `SETUP_GUIDE.md`
- **User Guide**: See `USER_GUIDE.md`
- **Stripe**: See `STRIPE_SETUP.md`
- **Deployment**: See `DEPLOYMENT_CHECKLIST.md`

## ✅ System Status

- ✅ Frontend: Ready
- ✅ Backend: Ready
- ✅ Database: Ready
- ✅ Authentication: Ready
- ⚠️ Payments: Needs Stripe configuration

## 🎉 You're All Set!

Once Stripe is configured, your system is ready to use. Enjoy! 🚀

---

**Need more details?** Check the other documentation files in this folder.
