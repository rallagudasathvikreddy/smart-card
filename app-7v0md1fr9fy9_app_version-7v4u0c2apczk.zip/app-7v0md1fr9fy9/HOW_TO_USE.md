# 🚀 How to Use - Hyderabad Smart Card Portal

## Quick Start (3 Simple Steps)

### Step 1: Open the Application ✅
When you open the application, you'll see the **Login Page**.

### Step 2: Create Account or Login ✅

**For New Users:**
- Click the **"Sign Up"** tab
- Fill in your details (Name, Email, Password)
- Click **"Create Account"**
- ✅ Done! You'll automatically go to the Dashboard

**For Existing Users:**
- Stay on the **"Login"** tab
- Enter your email and password
- Click **"Login"**
- ✅ Done! You'll automatically go to the Dashboard

### Step 3: You're Now on the Dashboard! 🎉

You'll see:
- **Header** with navigation menu at the top
- **Overview Cards** showing your stats
- **Quick Action Buttons** to get started

## What You Can Do from the Dashboard

### 1️⃣ Register a New Card
**Click**: "Register New Card" button on Dashboard

**What it does**: Creates a new smart card for you

**You'll need**:
- Your full name
- Phone number
- ID proof details
- Choose card type (General, Student, or Senior Citizen)

**Result**: You get a unique card number

---

### 2️⃣ Check Your Balance
**Click**: "Balance & Recharge" in the top menu

**What you'll see**:
- All your registered cards
- Current balance on each card
- Transaction history
- Recharge button

---

### 3️⃣ Recharge Your Card
**From**: Balance & Recharge page

**Steps**:
1. Find your card
2. Click "Recharge" button
3. Enter amount (₹50, ₹100, ₹200, ₹500, or custom)
4. Click "Proceed to Payment"
5. Complete payment on Stripe
6. ✅ Balance updated automatically!

**Note**: Requires Stripe configuration (see STRIPE_SETUP.md)

---

### 4️⃣ Apply for a Travel Pass
**Click**: "Apply for Pass" in the top menu

**Pass Types Available**:
- **Daily Pass**: ₹50 (valid for 1 day)
- **Weekly Pass**: ₹300 (valid for 7 days)
- **Monthly Pass**: ₹1000 (valid for 30 days)
- **Student Pass**: ₹600 (valid for 30 days)
- **Senior Citizen Pass**: ₹500 (valid for 30 days)

**Steps**:
1. Select your card
2. Choose pass type
3. Select route/zone
4. Click "Proceed to Payment"
5. Complete payment
6. ✅ Pass activated!

---

### 5️⃣ View Your Passes
**Click**: "My Passes" in the top menu

**What you'll see**:
- All your passes (Active, Pending, Expired)
- Pass details (type, validity, status)
- Expiry dates

---

### 6️⃣ Admin Dashboard (First User Only)
**Click**: Your name (top right) → "Admin Dashboard"

**What you can do**:
- View all users in the system
- See all registered cards
- Monitor all passes
- View transaction reports
- System statistics

**Who can access**: Only the first registered user (administrator)

---

## Navigation Menu Explained

When you're logged in, you'll see these menu items at the top:

```
🏠 Dashboard | 💳 Register Card | 💰 Balance & Recharge | 🎫 Apply for Pass | 📋 My Passes | 👤 [Your Name]
```

**Click any item to navigate to that page!**

---

## Complete Example: First Time User

### Scenario: Register and Recharge Your First Card

```
📱 STEP 1: Open App
   → You see the Login Page

📝 STEP 2: Sign Up
   → Click "Sign Up" tab
   → Enter: Name, Email, Password
   → Click "Create Account"
   → ✅ Success! Redirected to Dashboard

🏠 STEP 3: You're on Dashboard
   → See: 0 cards, ₹0 balance, 0 passes
   → Click "Register New Card" button

💳 STEP 4: Register Card
   → Fill form: Name, Phone, ID details
   → Select: Card Type (e.g., "General")
   → Click "Register Card"
   → ✅ Success! Card created with unique number

🏠 STEP 5: Back to Dashboard
   → Now shows: 1 card, ₹0 balance
   → Click "Balance & Recharge" in menu

💰 STEP 6: Recharge Card
   → See your card with ₹0 balance
   → Click "Recharge" button
   → Select amount: ₹500
   → Click "Proceed to Payment"
   → Complete payment on Stripe
   → ✅ Success! Balance now ₹500

🎫 STEP 7: Apply for Pass (Optional)
   → Click "Apply for Pass" in menu
   → Select your card
   → Choose "Monthly Pass" (₹1000)
   → Select route
   → Complete payment
   → ✅ Pass activated!

📋 STEP 8: View Everything
   → Dashboard shows: 1 card, ₹500 balance, 1 active pass
   → Click "My Passes" to see pass details
   → Click "Balance & Recharge" to see transactions
```

---

## Important Notes

### ✅ What Works Now
- User registration and login
- Card registration
- Balance checking
- Transaction history
- Pass application (UI)
- Admin dashboard
- All navigation

### ⚠️ What Needs Setup
- **Payment Processing**: Requires Stripe configuration
  - Without Stripe: You can register cards and apply for passes, but payment won't work
  - With Stripe: Full payment functionality enabled
  - Setup guide: See `STRIPE_SETUP.md`

### 🔐 Security
- All pages require login (except login page itself)
- Your data is private (only you can see your cards/passes)
- Admins can see all data for management purposes
- Passwords are encrypted

### 💡 Tips
- **First user becomes admin** - Register first to get admin access!
- **Bookmark the home page** - Don't bookmark internal pages
- **Use the navigation menu** - Don't use browser back button
- **Check dashboard regularly** - See your account overview
- **Keep your password safe** - Don't share with anyone

---

## Troubleshooting

### ❓ "I can't type in the input fields"
**Fixed!** The input fields now work properly. Just click and type.

### ❓ "How do I get to the dashboard?"
**Answer**: After login/signup, you're automatically redirected to the dashboard. No extra steps needed!

### ❓ "I don't see the navigation menu"
**Check**: 
- Are you logged in? (You should see your name in top right)
- Try refreshing the page
- Make sure login was successful

### ❓ "Payment is not working"
**Answer**: Stripe needs to be configured first. See `STRIPE_SETUP.md` for instructions.

### ❓ "I can't see Admin Dashboard"
**Answer**: Only the first registered user is an admin. If you're not the first user, you won't see this option.

### ❓ "Dashboard shows 0 for everything"
**Answer**: That's normal for new users! Register a card first, then the numbers will update.

---

## Summary

### To Access Dashboard:
1. **New User**: Sign Up → Automatically redirected to Dashboard ✅
2. **Existing User**: Login → Automatically redirected to Dashboard ✅

### From Dashboard You Can:
- Register cards
- Check balances
- Recharge cards
- Apply for passes
- View passes
- Access admin panel (if admin)

### Navigation:
- Use the menu at the top to move between pages
- Click logo to return to Dashboard
- Click your name for profile options

---

**That's it! You're ready to use the Hyderabad Smart Card Portal! 🎉**

For more details:
- Login testing: See `TEST_LOGIN.md`
- Navigation details: See `NAVIGATION_GUIDE.md`
- Stripe setup: See `STRIPE_SETUP.md`
- Complete guide: See `USER_GUIDE.md`
