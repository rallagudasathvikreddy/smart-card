/*
# Hyderabad Smart Card Portal - Database Schema

## Plain English Explanation
This migration creates the complete database structure for the Hyderabad Smart Card Management System. It includes user profiles, smart cards, transactions, passes, and orders tables with appropriate relationships and security policies.

## Tables Created

### 1. profiles
- `id` (uuid, primary key, references auth.users)
- `email` (text, unique)
- `full_name` (text)
- `phone` (text)
- `id_proof_type` (text) - Type of ID proof (Aadhar, PAN, etc.)
- `id_proof_number` (text) - ID proof number
- `role` (user_role enum: 'user', 'admin')
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 2. cards
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `card_number` (text, unique) - 16-digit card number
- `card_type` (card_type enum: 'general', 'student', 'senior_citizen')
- `balance` (numeric) - Current balance in INR
- `status` (card_status enum: 'active', 'blocked', 'expired')
- `issued_date` (timestamptz)
- `expiry_date` (timestamptz)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 3. transactions
- `id` (uuid, primary key)
- `card_id` (uuid, references cards)
- `user_id` (uuid, references profiles)
- `type` (transaction_type enum: 'recharge', 'deduction', 'refund')
- `amount` (numeric)
- `balance_after` (numeric) - Balance after transaction
- `description` (text)
- `location` (text) - For deductions: bus/metro station
- `created_at` (timestamptz)

### 4. passes
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `card_id` (uuid, references cards)
- `pass_type` (pass_type enum: 'daily', 'weekly', 'monthly', 'student', 'senior_citizen')
- `route_zone` (text) - Route or zone for pass validity
- `price` (numeric)
- `status` (pass_status enum: 'pending', 'active', 'expired', 'cancelled')
- `start_date` (timestamptz)
- `end_date` (timestamptz)
- `document_url` (text) - URL to uploaded documents
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 5. orders
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `items` (jsonb) - Order items details
- `total_amount` (numeric)
- `currency` (text, default: 'inr')
- `status` (order_status enum: 'pending', 'completed', 'cancelled', 'refunded')
- `stripe_session_id` (text, unique)
- `stripe_payment_intent_id` (text)
- `customer_email` (text)
- `customer_name` (text)
- `completed_at` (timestamptz)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

## Security Policies

### profiles table
- RLS enabled
- Users can view their own profile
- Users can update their own profile (except role field)
- Admins have full access to all profiles

### cards table
- RLS enabled
- Users can view their own cards
- Only service role (via RPC) can create/update cards
- Admins can view all cards

### transactions table
- RLS enabled
- Users can view their own transactions
- Only service role can insert transactions

### passes table
- RLS enabled
- Users can view and create their own passes
- Users can update their own pending passes
- Admins can view and update all passes

### orders table
- RLS enabled
- Users can view their own orders
- Only service role (via Edge Functions) can manage orders

## RPC Functions

### is_admin
- Checks if a user has admin role
- Used in RLS policies

### update_card_balance
- Atomically updates card balance and creates transaction record
- Ensures data consistency

### generate_card_number
- Generates unique 16-digit card number
- Format: 5400XXXXXXXXXXXX (starts with 5400)

## Storage Bucket

### app-7v0md1fr9fy9_documents
- For storing ID proofs and pass application documents
- Max file size: 2MB
- Allowed MIME types: image/*, application/pdf

## Triggers

### handle_new_user
- Automatically creates profile entry when auth user is confirmed
- First user gets admin role, subsequent users get user role

### update_updated_at
- Automatically updates updated_at timestamp on record modification
*/

-- Create ENUM types
CREATE TYPE user_role AS ENUM ('user', 'admin');
CREATE TYPE card_type AS ENUM ('general', 'student', 'senior_citizen');
CREATE TYPE card_status AS ENUM ('active', 'blocked', 'expired');
CREATE TYPE transaction_type AS ENUM ('recharge', 'deduction', 'refund');
CREATE TYPE pass_type AS ENUM ('daily', 'weekly', 'monthly', 'student', 'senior_citizen');
CREATE TYPE pass_status AS ENUM ('pending', 'active', 'expired', 'cancelled');
CREATE TYPE order_status AS ENUM ('pending', 'completed', 'cancelled', 'refunded');

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE,
  full_name text,
  phone text,
  id_proof_type text,
  id_proof_number text,
  role user_role DEFAULT 'user'::user_role NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create cards table
CREATE TABLE IF NOT EXISTS cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  card_number text UNIQUE NOT NULL,
  card_type card_type NOT NULL,
  balance numeric(10,2) DEFAULT 0 NOT NULL CHECK (balance >= 0),
  status card_status DEFAULT 'active'::card_status NOT NULL,
  issued_date timestamptz DEFAULT now(),
  expiry_date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  card_id uuid REFERENCES cards(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  type transaction_type NOT NULL,
  amount numeric(10,2) NOT NULL,
  balance_after numeric(10,2) NOT NULL,
  description text,
  location text,
  created_at timestamptz DEFAULT now()
);

-- Create passes table
CREATE TABLE IF NOT EXISTS passes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  card_id uuid REFERENCES cards(id) ON DELETE SET NULL,
  pass_type pass_type NOT NULL,
  route_zone text NOT NULL,
  price numeric(10,2) NOT NULL,
  status pass_status DEFAULT 'pending'::pass_status NOT NULL,
  start_date timestamptz,
  end_date timestamptz,
  document_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  items jsonb NOT NULL,
  total_amount numeric(12,2) NOT NULL,
  currency text DEFAULT 'inr' NOT NULL,
  status order_status DEFAULT 'pending'::order_status NOT NULL,
  stripe_session_id text UNIQUE,
  stripe_payment_intent_id text,
  customer_email text,
  customer_name text,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_cards_user_id ON cards(user_id);
CREATE INDEX idx_cards_card_number ON cards(card_number);
CREATE INDEX idx_transactions_card_id ON transactions(card_id);
CREATE INDEX idx_transactions_user_id ON transactions(user_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX idx_passes_user_id ON passes(user_id);
CREATE INDEX idx_passes_status ON passes(status);
CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_stripe_session_id ON orders(stripe_session_id);
CREATE INDEX idx_orders_status ON orders(status);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE passes ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Create helper function to check admin role
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id)
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL USING (is_admin(auth.uid()));

-- RLS Policies for cards
CREATE POLICY "Users can view own cards" ON cards
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all cards" ON cards
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Service role can manage cards" ON cards
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- RLS Policies for transactions
CREATE POLICY "Users can view own transactions" ON transactions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all transactions" ON transactions
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Service role can manage transactions" ON transactions
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- RLS Policies for passes
CREATE POLICY "Users can view own passes" ON passes
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own passes" ON passes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pending passes" ON passes
  FOR UPDATE USING (auth.uid() = user_id AND status = 'pending'::pass_status);

CREATE POLICY "Admins can manage all passes" ON passes
  FOR ALL USING (is_admin(auth.uid()));

-- RLS Policies for orders
CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage orders" ON orders
  FOR ALL USING (auth.jwt()->>'role' = 'service_role');

-- Create RPC function to update card balance atomically
CREATE OR REPLACE FUNCTION update_card_balance(
  p_card_id uuid,
  p_user_id uuid,
  p_type transaction_type,
  p_amount numeric,
  p_description text DEFAULT NULL,
  p_location text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_balance numeric;
  v_new_balance numeric;
  v_transaction_id uuid;
BEGIN
  -- Get current balance with row lock
  SELECT balance INTO v_current_balance
  FROM cards
  WHERE id = p_card_id AND user_id = p_user_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Card not found or access denied';
  END IF;

  -- Calculate new balance
  IF p_type = 'recharge'::transaction_type OR p_type = 'refund'::transaction_type THEN
    v_new_balance := v_current_balance + p_amount;
  ELSIF p_type = 'deduction'::transaction_type THEN
    IF v_current_balance < p_amount THEN
      RAISE EXCEPTION 'Insufficient balance';
    END IF;
    v_new_balance := v_current_balance - p_amount;
  ELSE
    RAISE EXCEPTION 'Invalid transaction type';
  END IF;

  -- Update card balance
  UPDATE cards
  SET balance = v_new_balance, updated_at = now()
  WHERE id = p_card_id;

  -- Create transaction record
  INSERT INTO transactions (card_id, user_id, type, amount, balance_after, description, location)
  VALUES (p_card_id, p_user_id, p_type, p_amount, v_new_balance, p_description, p_location)
  RETURNING id INTO v_transaction_id;

  RETURN jsonb_build_object(
    'transaction_id', v_transaction_id,
    'previous_balance', v_current_balance,
    'new_balance', v_new_balance
  );
END;
$$;

-- Create RPC function to generate unique card number
CREATE OR REPLACE FUNCTION generate_card_number()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_card_number text;
  v_exists boolean;
BEGIN
  LOOP
    -- Generate 16-digit card number starting with 5400
    v_card_number := '5400' || lpad(floor(random() * 1000000000000)::text, 12, '0');
    
    -- Check if it already exists
    SELECT EXISTS(SELECT 1 FROM cards WHERE card_number = v_card_number) INTO v_exists;
    
    EXIT WHEN NOT v_exists;
  END LOOP;
  
  RETURN v_card_number;
END;
$$;

-- Create trigger function for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_cards_updated_at BEFORE UPDATE ON cards
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_passes_updated_at BEFORE UPDATE ON passes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create trigger for new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  IF OLD IS DISTINCT FROM NULL AND OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL THEN
    SELECT COUNT(*) INTO user_count FROM profiles;
    
    INSERT INTO profiles (id, email, full_name, phone, role)
    VALUES (
      NEW.id,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
      NEW.phone,
      CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7v0md1fr9fy9_documents',
  'app-7v0md1fr9fy9_documents',
  false,
  2097152,
  ARRAY['image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'application/pdf']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for documents bucket
CREATE POLICY "Authenticated users can upload documents"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'app-7v0md1fr9fy9_documents');

CREATE POLICY "Users can view own documents"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'app-7v0md1fr9fy9_documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Admins can view all documents"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'app-7v0md1fr9fy9_documents' AND is_admin(auth.uid()));

CREATE POLICY "Users can delete own documents"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'app-7v0md1fr9fy9_documents' AND auth.uid()::text = (storage.foldername(name))[1]);